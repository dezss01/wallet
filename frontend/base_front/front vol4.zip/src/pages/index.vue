<template>
  <user-registration-app></user-registration-app>
</template>

<script setup>
//
import UserRegistrationApp from "@/pages/UserRegistration.vue";
</script>
