// import axios from "axios";
// axios.defaults.withCredentials = true

// const apiClient = axios.create({
//   baseURL: '/api',
//   headers: {
//     'Content-Type': 'application/json',
//     'Accept': 'application/json'
//   }
// })
